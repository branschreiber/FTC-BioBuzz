# BIOBUZZ Field Guide

A GitHub Pages website with a manual-grounded BIOBUZZ Q&A assistant.

## Files
- `index.html` — responsive chat website.
- `worker.js` — Cloudflare Worker backend. The API key stays server-side.

## 1. Publish with GitHub Pages
1. Open repository **Settings → Pages**.
2. Choose **Deploy from a branch**.
3. Select branch `main` and folder `/(root)`, then Save.
4. The site URL should be `https://branschreiber.github.io/FTC-BioBuzz/`.

## 2. Add the official manual to a searchable vector store
The bot needs the actual PDF in a vector store; the public website does not contain the manual.
1. In the OpenAI Platform, create a project/API key and a vector store.
2. Upload `BIOBUZZ_Competition_Manual_V1.pdf` to the vector store.
3. Copy the vector store ID (starts with `vs_`).
4. Keep the API key private. Never put it in `index.html` or commit it to GitHub.

Documentation: https://platform.openai.com/docs/guides/tools-file-search

## 3. Deploy the secure backend
1. Create a Cloudflare Worker.
2. Paste `worker.js` into its editor and deploy.
3. In Worker **Settings → Variables and Secrets**, add:
   - Secret `OPENAI_API_KEY` = private OpenAI API key.
   - Variable `OPENAI_VECTOR_STORE_ID` = vector store ID.
   - Optional variable `OPENAI_MODEL` = `gpt-5.5`.
   - Optional variable `ALLOWED_ORIGIN` = `https://branschreiber.github.io`.
4. Copy the Worker URL.

## 4. Connect the website
In `index.html`, replace the `API_URL` placeholder with your Worker URL, commit the change, and wait for GitHub Pages to redeploy.

## Notes
- The assistant is instructed to ground official-rule answers in the uploaded manual, cite rule/page references when available, and say when the manual does not specify.
- Official Team Updates may supersede V1. Check the latest updates before relying on a rule at an event.
- API usage may cost money. Ask a parent/guardian to review account setup and spending limits before enabling paid API access.
